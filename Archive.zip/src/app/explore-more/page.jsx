import React from 'react';

const ExploreMore = () => {
  return (
    <div>
      <h1 className="text-white">Hello , this is Explore section</h1>
    </div>
  );
};

export default ExploreMore;
