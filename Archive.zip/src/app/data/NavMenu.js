export const NavMenu = [
  {
    name: 'Muhammad Musabbir',
    submenu: false,
    ink: 'Name',
  },
  {
    name: 'Design',
    submenu: false,
    link: 'Design',
  },
  {
    name: 'About Me',
    submenu: false,
    link: 'about',
  },
  {
    name: 'Resume',
    submenu: false,
    link: 'Resume',
  },
  {
    name: 'Contact',
    submenu: false,
    link: 'Contact',
  },
];
