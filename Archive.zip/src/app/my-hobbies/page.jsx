import React from 'react';

const MyHobbies = () => {
  return (
    <div>
      <h1 className="text-white">Hello , this is hobbies section</h1>
    </div>
  );
};

export default MyHobbies;
